package com.ureca;

public class A {
	public String getMsg() {
		return "회덮밥 하쥐만! 우린 봉구스 밥버거~^6^";
	}
}
