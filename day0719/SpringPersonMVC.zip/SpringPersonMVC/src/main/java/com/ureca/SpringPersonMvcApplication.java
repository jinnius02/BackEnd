package com.ureca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPersonMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPersonMvcApplication.class, args);
	}

}
