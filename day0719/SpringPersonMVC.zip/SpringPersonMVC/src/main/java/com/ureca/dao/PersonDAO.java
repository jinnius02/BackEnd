package com.ureca.dao;

public interface PersonDAO {
	
	public void insert();
	public void update();
	public void delete();
	
	public void select(); //특정 Person 한 명 조회
	public void selectAll(); //모든 Person 조회
}
