package com.ureca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
